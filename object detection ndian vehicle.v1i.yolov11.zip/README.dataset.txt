# object detection ndian vehicle > 2025-04-10 9:26pm
https://universe.roboflow.com/swarnavo/object-detection-ndian-vehicle

Provided by a Roboflow user
License: MIT

